plugins {
    id("com.android.application") version "9.6.0" apply false
}
