# WorldBridge for Android

WorldBridge is an offline Android utility for pruning selected Minecraft Bedrock chunk columns from an exported `.mcworld` file.

**Behaviour:** the rectangle selected by the user is removed from one chosen dimension. Chunks outside that rectangle, other dimensions, `level.dat`, and unrelated LevelDB keys are preserved. The imported `.mcworld` is never edited; WorldBridge works on a separate copy and exports a new `.mcworld`.

## Current app features

- Import a Bedrock `.mcworld` archive through Android's file picker.
- Create a protected original copy and a separate editable copy in app-private storage.
- Select Overworld, Nether, or The End independently.
- Build a top-down map preview from saved Bedrock chunk columns, height maps and biome data where available.
- Drag across the world map to select a rectangle; pinch to zoom and use two fingers to pan, or enter any min/max chunk coordinates manually.
- Refresh the map after pruning or restoring the protected copy, and switch the preview between Overworld, Nether and The End.
- Review the exact dimension and inclusive chunk-coordinate rectangle before deleting.
- Delete only chunk-column LevelDB records in the selected rectangle, in bounded batches.
- Compact the LevelDB database after pruning so deleted records can be reclaimed from the exported file.
- Restore the protected copy or export the working copy as a fresh `.mcworld` archive.

## How to use

1. In Minecraft, open the world edit screen and use **Export World** to create a `.mcworld` file. Close the world before exporting it.
2. Open WorldBridge and import that `.mcworld` file.
3. Choose a dimension.
4. Wait for the top-down map preview to load. Drag on the map to select an area, pinch to zoom, use two fingers to pan, or switch to manual entry for exact/large coordinate ranges.
5. Review the coordinates and confirm **Delete selected chunks**.
6. Export the edited copy to a new `.mcworld` file.
7. Open the new file with Minecraft. Keep the original export until you have checked the edited world in-game.

The map is a lightweight top-down overview, not a full 3D renderer. It uses Bedrock's stored 2D height-map and biome records, with 3D biome palette data when present. If a world does not contain readable biome/height-map records for a chunk, WorldBridge shows its saved chunk coverage in a neutral colour. The preview is dimension-specific and refreshes after edits.

## Build

Open this folder in Android Studio and allow Gradle to sync, or use the GitHub Actions workflow in `.github/workflows/build-apk.yml` to build a debug APK. The workflow uploads `app-debug.apk` as the `WorldBridge-debug-apk` artifact.

Build requirements (pinned in this project):

- Android Gradle Plugin 9.6.0
- Gradle 9.8.2 (the included `gradlew` launcher downloads this pinned version)
- Java 17
- Android SDK platform 37 and Build Tools 36.0.0

### Build on GitHub

The easiest build route when you only have a phone is to put the extracted project files into a GitHub repository, then open the repository's **Actions** tab and run **Build WorldBridge APK**. When the workflow finishes, open that run and download the **WorldBridge-debug-apk** artifact. It contains `app-debug.apk`.

## Safety and compatibility notes

- The app accepts exported Bedrock `.mcworld` files. It does not browse Minecraft's app-private world folder directly; Android restricts access to other apps' private data.
- The original selected file and the protected imported copy are not changed. Only the app's working copy is edited.
- WorldBridge uses the Bedrock LevelDB key layouts and removal strategy used by HiveGamesOSS/Chunker. It removes the per-column records (including sub-chunks and dimension-bearing variants) for the selected coordinates, while excluding the local-player key.
- The app is intended for Bedrock world archives. Java Edition world folders are not supported.
- Large worlds can require substantial free storage and time for LevelDB compaction. Make sure the phone has enough free space before starting.
- The preview scanner opens the working copy's LevelDB to read chunk positions and map data; it does not intentionally write or prune database records.
- This build has not yet been runtime-tested on a physical Android device, and the map preview has not yet been validated against a range of real Bedrock world versions. Test with a copy of a small world first and keep your original export.

## Third-party notices

The Bedrock chunk-key handling is based on the MIT-licensed Chunker project by Hive Games: https://github.com/HiveGamesOSS/Chunker . The original MIT copyright and permission notice is included in `THIRD_PARTY_NOTICES/CHUNKER-MIT.txt`.

The app uses the `com.hivemc.leveldb` Java LevelDB implementation, from https://github.com/HiveGamesOSS/leveldb-mcpe-java , licensed under Apache License 2.0. The Apache license and upstream copyright notice are included in `THIRD_PARTY_NOTICES/LEVELDB-APACHE-2.0.txt` and `THIRD_PARTY_NOTICES/LEVELDB-NOTICE.txt`.
