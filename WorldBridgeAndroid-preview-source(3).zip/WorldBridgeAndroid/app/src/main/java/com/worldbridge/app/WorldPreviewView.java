package com.worldbridge.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import com.worldbridge.engine.BedrockWorldPreview;

import java.util.Map;

/** Interactive top-down overview of saved Bedrock chunks with drag-to-select pruning. */
public final class WorldPreviewView extends View {
    public interface RegionListener {
        void onRegionChanged(int minX, int minZ, int maxX, int maxZ);
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private BedrockWorldPreview.PreviewData preview;
    private RegionListener listener;
    private int minX, minZ, maxX, maxZ;
    private boolean dragging;
    private int dragStartX, dragStartZ;
    private float scale = 1f;
    private float mapLeft, mapTop;
    private float baseScale = 1f;
    private boolean needsFit = true;
    private boolean scaling;
    private float lastMultiX, lastMultiY;
    private final ScaleGestureDetector scaleDetector;
    private final int background = 0xFF0B1422;
    private final int emptyColor = 0xFF253449;
    private final int selectionFill = 0x667CE0A4;
    private final int selectionStroke = 0xFF7CE0A4;

    public WorldPreviewView(Context context) {
        super(context);
        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScaleBegin(ScaleGestureDetector detector) {
                scaling = true;
                return true;
            }

            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                float oldScale = scale;
                float next = Math.max(baseScale * 0.55f, Math.min(baseScale * 24f, scale * detector.getScaleFactor()));
                if (oldScale > 0 && next != oldScale) {
                    float focusX = detector.getFocusX();
                    float focusY = detector.getFocusY();
                    mapLeft = focusX - (focusX - mapLeft) * (next / oldScale);
                    mapTop = focusY - (focusY - mapTop) * (next / oldScale);
                    scale = next;
                    invalidate();
                }
                return true;
            }

            @Override
            public void onScaleEnd(ScaleGestureDetector detector) {
                scaling = false;
            }
        });
        setFocusable(true);
    }

    public WorldPreviewView(Context context, AttributeSet attrs) {
        this(context);
    }

    public void setRegionListener(RegionListener listener) {
        this.listener = listener;
    }

    public void setPreview(BedrockWorldPreview.PreviewData preview) {
        this.preview = preview;
        needsFit = true;
        requestLayout();
        invalidate();
    }

    public void setRegion(int minX, int minZ, int maxX, int maxZ) {
        this.minX = Math.min(minX, maxX);
        this.maxX = Math.max(minX, maxX);
        this.minZ = Math.min(minZ, maxZ);
        this.maxZ = Math.max(minZ, maxZ);
        invalidate();
    }

    public void resetView() {
        needsFit = true;
        invalidate();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int desired = (int) (300 * getResources().getDisplayMetrics().density);
        int height = resolveSize(desired, heightMeasureSpec);
        setMeasuredDimension(resolveSize(width, widthMeasureSpec), height);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        needsFit = true;
    }

    private void fitWorld() {
        if (preview == null || preview.tiles.isEmpty() || getWidth() <= 0 || getHeight() <= 0) return;
        float worldW = Math.max(1L, (long) preview.maxChunkX - preview.minChunkX + 1L);
        float worldH = Math.max(1L, (long) preview.maxChunkZ - preview.minChunkZ + 1L);
        float availableW = Math.max(1, getWidth() - dp(38));
        float availableH = Math.max(1, getHeight() - dp(38));
        baseScale = Math.min(availableW / worldW, availableH / worldH);
        baseScale = Math.max(0.08f, Math.min(baseScale, dp(100)));
        scale = baseScale;
        mapLeft = (getWidth() - worldW * scale) / 2f - preview.minChunkX * scale;
        mapTop = (getHeight() - worldH * scale) / 2f - preview.minChunkZ * scale;
        needsFit = false;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(background);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFF111E30);
        canvas.drawRoundRect(dp(7), dp(7), getWidth() - dp(7), getHeight() - dp(7), dp(12), dp(12), paint);

        if (preview == null) {
            drawCentered(canvas, "Import a world to build its map preview", 13, 0xFF9DAEC3);
            return;
        }
        if (preview.tiles.isEmpty()) {
            drawCentered(canvas, "No saved chunks in this dimension", 13, 0xFF9DAEC3);
            return;
        }
        if (needsFit) fitWorld();

        float chunkSize = scale;
        for (Map.Entry<Long, int[]> entry : preview.tiles.entrySet()) {
            long key = entry.getKey();
            int chunkX = (int) (key >> 32);
            int chunkZ = (int) key;
            float left = mapLeft + chunkX * chunkSize;
            float top = mapTop + chunkZ * chunkSize;
            if (left + chunkSize < 0 || top + chunkSize < 0 || left > getWidth() || top > getHeight()) continue;
            int[] pixels = entry.getValue();
            if (chunkSize >= dp(7) && pixels != null && pixels.length >= 16) {
                float pixelSize = chunkSize / 4f;
                for (int pz = 0; pz < 4; pz++) {
                    for (int px = 0; px < 4; px++) {
                        paint.setColor(pixels[pz * 4 + px]);
                        float x = left + px * pixelSize;
                        float y = top + pz * pixelSize;
                        canvas.drawRect(x, y, x + pixelSize + 0.4f, y + pixelSize + 0.4f, paint);
                    }
                }
            } else {
                paint.setColor(average(pixels));
                canvas.drawRect(left, top, left + Math.max(chunkSize, 0.45f), top + Math.max(chunkSize, 0.45f), paint);
            }
        }

        drawSelection(canvas);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(0x553D5570);
        rect.set(dp(7), dp(7), getWidth() - dp(7), getHeight() - dp(7));
        canvas.drawRoundRect(rect, dp(12), dp(12), paint);
        paint.setStyle(Paint.Style.FILL);

        paint.setColor(0xFFDCE8F6);
        paint.setTextSize(dp(10));
        paint.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        canvas.drawText("X " + preview.minChunkX + " … " + preview.maxChunkX, dp(14), getHeight() - dp(13), paint);
        String zLabel = "Z " + preview.minChunkZ + " … " + preview.maxChunkZ;
        canvas.drawText(zLabel, getWidth() - dp(14) - paint.measureText(zLabel), getHeight() - dp(13), paint);
    }

    private void drawSelection(Canvas canvas) {
        if (preview == null || scale <= 0) return;
        int leftChunk = Math.max(minX, preview.minChunkX);
        int rightChunk = Math.min(maxX, preview.maxChunkX);
        int topChunk = Math.max(minZ, preview.minChunkZ);
        int bottomChunk = Math.min(maxZ, preview.maxChunkZ);
        if (leftChunk > rightChunk || topChunk > bottomChunk) return;
        float left = mapLeft + leftChunk * scale;
        float top = mapTop + topChunk * scale;
        float right = mapLeft + (rightChunk + 1f) * scale;
        float bottom = mapTop + (bottomChunk + 1f) * scale;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(selectionFill);
        canvas.drawRect(left, top, right, bottom, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(2));
        paint.setColor(selectionStroke);
        canvas.drawRect(left, top, right, bottom, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private int average(int[] colors) {
        if (colors == null || colors.length == 0) return emptyColor;
        long r = 0, g = 0, b = 0;
        for (int color : colors) {
            r += (color >>> 16) & 255;
            g += (color >>> 8) & 255;
            b += color & 255;
        }
        int count = colors.length;
        return 0xFF000000 | ((int) (r / count) << 16) | ((int) (g / count) << 8) | (int) (b / count);
    }

    private void drawCentered(Canvas canvas, String message, int textSize, int color) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        paint.setTextSize(dp(textSize));
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText(message, getWidth() / 2f, getHeight() / 2f, paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        if (event.getPointerCount() >= 2) {
            if (event.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN) {
                // A pinch/pan gesture takes over from rectangle selection.
                dragging = false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                lastMultiX = focusX(event);
                lastMultiY = focusY(event);
            } else if (event.getActionMasked() == MotionEvent.ACTION_MOVE && !scaleDetector.isInProgress()) {
                float x = focusX(event), y = focusY(event);
                mapLeft += x - lastMultiX;
                mapTop += y - lastMultiY;
                lastMultiX = x;
                lastMultiY = y;
                invalidate();
            }
            if (event.getActionMasked() == MotionEvent.ACTION_POINTER_UP) {
                lastMultiX = focusX(event);
                lastMultiY = focusY(event);
            }
            if (event.getActionMasked() == MotionEvent.ACTION_UP) {
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
            }
            return true;
        }
        if (scaling || preview == null || preview.tiles.isEmpty()) return true;
        if (!dragging && event.getActionMasked() == MotionEvent.ACTION_UP) {
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
            return true;
        }
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                int[] chunk = chunkAt(event.getX(), event.getY());
                if (chunk == null) return false;
                dragStartX = chunk[0];
                dragStartZ = chunk[1];
                dragging = true;
                updateRegion(chunk[0], chunk[1]);
                getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (!dragging) return false;
                int[] chunk = chunkAtClamped(event.getX(), event.getY());
                updateRegion(chunk[0], chunk[1]);
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                if (!dragging) return false;
                int[] chunk = chunkAtClamped(event.getX(), event.getY());
                updateRegion(chunk[0], chunk[1]);
                dragging = false;
                getParent().requestDisallowInterceptTouchEvent(false);
                performClick();
                return true;
            }
        }
        return true;
    }

    private float focusX(MotionEvent event) {
        float sum = 0;
        for (int i = 0; i < event.getPointerCount(); i++) sum += event.getX(i);
        return sum / event.getPointerCount();
    }

    private float focusY(MotionEvent event) {
        float sum = 0;
        for (int i = 0; i < event.getPointerCount(); i++) sum += event.getY(i);
        return sum / event.getPointerCount();
    }

    private int[] chunkAt(float x, float y) {
        int cx = (int) Math.floor((x - mapLeft) / scale);
        int cz = (int) Math.floor((y - mapTop) / scale);
        if (cx < preview.minChunkX || cx > preview.maxChunkX || cz < preview.minChunkZ || cz > preview.maxChunkZ) return null;
        return new int[]{cx, cz};
    }

    private int[] chunkAtClamped(float x, float y) {
        int cx = (int) Math.floor((x - mapLeft) / scale);
        int cz = (int) Math.floor((y - mapTop) / scale);
        cx = Math.max(preview.minChunkX, Math.min(preview.maxChunkX, cx));
        cz = Math.max(preview.minChunkZ, Math.min(preview.maxChunkZ, cz));
        return new int[]{cx, cz};
    }

    private void updateRegion(int x, int z) {
        minX = Math.min(dragStartX, x);
        maxX = Math.max(dragStartX, x);
        minZ = Math.min(dragStartZ, z);
        maxZ = Math.max(dragStartZ, z);
        invalidate();
        if (listener != null) listener.onRegionChanged(minX, minZ, maxX, maxZ);
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
