package com.worldbridge.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.worldbridge.engine.BedrockChunkPruner;
import com.worldbridge.engine.BedrockWorldPreview;

import java.io.File;
import java.io.OutputStream;
import java.math.BigInteger;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQUEST_OPEN_WORLD = 1001;
    private static final int REQUEST_CREATE_WORLD = 1002;

    private static final int BG = 0xFF0A1220;
    private static final int PANEL = 0xFF121F32;
    private static final int PANEL_SOFT = 0xFF17263B;
    private static final int ACCENT = 0xFF7CE0A4;
    private static final int TEXT = 0xFFEAF1FA;
    private static final int MUTED = 0xFF9DAEC3;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private File workspace;
    private File originalWorld;
    private File workingWorld;
    private String worldName = "No world selected";
    private boolean worldLoaded;
    private boolean busy;
    private Uri lastExportUri;
    private int selectionMinX = 0;
    private int selectionMinZ = 0;
    private int selectionMaxX = 0;
    private int selectionMaxZ = 0;
    private boolean manualMode;

    private TextView worldStatus;
    private TextView selectionStatus;
    private TextView actionStatus;
    private TextView modeVisual;
    private TextView modeManual;
    private WorldPreviewView mapView;
    private TextView previewStatus;
    private int previewRequestId;
    private LinearLayout manualPanel;
    private EditText minXInput;
    private EditText minZInput;
    private EditText maxXInput;
    private EditText maxZInput;
    private Spinner dimensionSpinner;
    private Button importButton;
    private Button pruneButton;
    private Button exportButton;
    private Button resetButton;
    private Button openButton;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        workspace = new File(getFilesDir(), "worldbridge");
        originalWorld = new File(workspace, "original");
        workingWorld = new File(workspace, "working");
        buildUi();
        restoreWorkspace();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(22), dp(18), dp(28));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));

        TextView eyebrow = label("MINECRAFT BEDROCK TOOL", 11, ACCENT, true);
        eyebrow.setLetterSpacing(0.13f);
        content.addView(eyebrow);
        TextView title = label("WorldBridge", 32, TEXT, true);
        title.setPadding(0, dp(5), 0, 0);
        content.addView(title);
        TextView subtitle = label("Trim selected chunks. Keep everything around them.", 14, MUTED, false);
        subtitle.setPadding(0, dp(5), 0, dp(18));
        content.addView(subtitle);

        LinearLayout importCard = panel();
        content.addView(importCard, margin(0, 0, 0, 14));
        TextView importTitle = label("1  ·  Choose your world", 17, TEXT, true);
        importCard.addView(importTitle);
        TextView importHint = label("Export the world from Minecraft as a .mcworld file, then open it here. Your original file is never edited.", 13, MUTED, false);
        importHint.setPadding(0, dp(7), 0, dp(12));
        importCard.addView(importHint);
        importButton = actionButton("Import .mcworld", ACCENT, BG);
        importButton.setOnClickListener(v -> chooseWorld());
        importCard.addView(importButton, matchWrap());
        worldStatus = label(worldName, 13, MUTED, false);
        worldStatus.setPadding(0, dp(10), 0, 0);
        importCard.addView(worldStatus);

        LinearLayout settingsCard = panel();
        content.addView(settingsCard, margin(0, 0, 0, 14));
        settingsCard.addView(label("2  ·  Choose a dimension", 17, TEXT, true));
        dimensionSpinner = new Spinner(this);
        String[] dimensions = {"Overworld", "Nether", "The End"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, dimensions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dimensionSpinner.setAdapter(adapter);
        dimensionSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (worldLoaded && !busy) loadWorldPreview();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
        LinearLayout.LayoutParams spinnerParams = matchWrap();
        spinnerParams.topMargin = dp(10);
        settingsCard.addView(dimensionSpinner, spinnerParams);

        LinearLayout selectionCard = panel();
        content.addView(selectionCard, margin(0, 0, 0, 14));
        selectionCard.addView(label("3  ·  Select the chunks to remove", 17, TEXT, true));
        TextView selectionHint = label("Top-down world preview. Drag across the map to mark chunks; pinch to zoom and use two fingers to move around. Only the highlighted area is removed.", 13, MUTED, false);
        selectionHint.setPadding(0, dp(7), 0, dp(12));
        selectionCard.addView(selectionHint);

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        modeVisual = modeButton("Drag on map", true);
        modeManual = modeButton("Enter coordinates", false);
        modeRow.addView(modeVisual, new LinearLayout.LayoutParams(0, dp(42), 1));
        LinearLayout.LayoutParams modeManualParams = new LinearLayout.LayoutParams(0, dp(42), 1);
        modeManualParams.leftMargin = dp(8);
        modeRow.addView(modeManual, modeManualParams);
        selectionCard.addView(modeRow);
        modeVisual.setOnClickListener(v -> setManualMode(false));
        modeManual.setOnClickListener(v -> setManualMode(true));

        mapView = new WorldPreviewView(this);
        mapView.setRegion(0, 0, 0, 0);
        mapView.setRegionListener((minX, minZ, maxX, maxZ) -> {
            selectionMinX = minX;
            selectionMinZ = minZ;
            selectionMaxX = maxX;
            selectionMaxZ = maxZ;
            syncManualInputs();
            updateSelectionStatus();
        });
        LinearLayout.LayoutParams mapParams = matchWrap();
        mapParams.topMargin = dp(12);
        selectionCard.addView(mapView, mapParams);
        previewStatus = label("Import a .mcworld file to build the map preview.", 12, MUTED, false);
        previewStatus.setPadding(0, dp(8), 0, 0);
        selectionCard.addView(previewStatus);
        TextView mapLegend = label("Map colours are approximate: blue = water · green = vegetation · tan = dry biomes · pale = snowy areas · red/brown = Nether biomes.", 11, MUTED, false);
        mapLegend.setPadding(0, dp(5), 0, 0);
        selectionCard.addView(mapLegend);

        manualPanel = new LinearLayout(this);
        manualPanel.setOrientation(LinearLayout.VERTICAL);
        manualPanel.setPadding(0, dp(12), 0, 0);
        manualPanel.setVisibility(View.GONE);
        TextView manualHint = label("Use chunk coordinates, not block coordinates. Negative coordinates are allowed.", 12, MUTED, false);
        manualHint.setPadding(0, 0, 0, dp(8));
        manualPanel.addView(manualHint);
        manualPanel.addView(coordinateRow(true));
        LinearLayout.LayoutParams row2Params = matchWrap();
        row2Params.topMargin = dp(8);
        manualPanel.addView(coordinateRow(false), row2Params);
        selectionCard.addView(manualPanel);

        selectionStatus = label("Selected: X 0 to 0  ·  Z 0 to 0  ·  1 chunk column", 13, ACCENT, true);
        selectionStatus.setPadding(0, dp(12), 0, 0);
        selectionCard.addView(selectionStatus);

        LinearLayout actionCard = panel();
        content.addView(actionCard, margin(0, 0, 0, 14));
        actionCard.addView(label("4  ·  Review and prune", 17, TEXT, true));
        TextView actionHint = label("WorldBridge makes a separate working copy first. The .mcworld you imported stays untouched.", 13, MUTED, false);
        actionHint.setPadding(0, dp(7), 0, dp(12));
        actionCard.addView(actionHint);

        pruneButton = actionButton("Review selected area", ACCENT, BG);
        pruneButton.setOnClickListener(v -> reviewAndPrune());
        actionCard.addView(pruneButton, matchWrap());
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setIndeterminate(true);
        progressBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressParams = matchWrap();
        progressParams.topMargin = dp(10);
        actionCard.addView(progressBar, progressParams);
        actionStatus = label("Ready when your world is imported.", 12, MUTED, false);
        actionStatus.setPadding(0, dp(10), 0, 0);
        actionCard.addView(actionStatus);

        LinearLayout exportCard = panel();
        content.addView(exportCard, margin(0, 0, 0, 14));
        exportCard.addView(label("5  ·  Export back to Minecraft", 17, TEXT, true));
        TextView exportHint = label("Save the edited copy as a new .mcworld file, then open that file with Minecraft.", 13, MUTED, false);
        exportHint.setPadding(0, dp(7), 0, dp(12));
        exportCard.addView(exportHint);
        exportButton = actionButton("Export .mcworld", 0xFF243851, TEXT);
        exportButton.setOnClickListener(v -> chooseExportDestination());
        exportButton.setEnabled(false);
        exportCard.addView(exportButton, matchWrap());
        openButton = actionButton("Open saved world", 0xFF243851, TEXT);
        openButton.setVisibility(View.GONE);
        openButton.setOnClickListener(v -> openLastExport());
        LinearLayout.LayoutParams openParams = matchWrap();
        openParams.topMargin = dp(8);
        exportCard.addView(openButton, openParams);
        resetButton = actionButton("Restore original copy", 0xFF243851, TEXT);
        resetButton.setEnabled(false);
        resetButton.setOnClickListener(v -> confirmReset());
        LinearLayout.LayoutParams resetParams = matchWrap();
        resetParams.topMargin = dp(8);
        exportCard.addView(resetButton, resetParams);

        TextView footer = label("Offline processing  ·  No account required  ·  Minecraft Bedrock worlds only", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(4), 0, dp(4));
        content.addView(footer);

        setContentView(scroll);
        syncManualInputs();
        updateSelectionStatus();
        updateButtons();
    }

    private LinearLayout coordinateRow(boolean minimumRow) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        if (minimumRow) {
            minXInput = coordinateInput("Min chunk X");
            minZInput = coordinateInput("Min chunk Z");
            row.addView(minXInput, new LinearLayout.LayoutParams(0, dp(52), 1));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(52), 1);
            p.leftMargin = dp(8);
            row.addView(minZInput, p);
        } else {
            maxXInput = coordinateInput("Max chunk X");
            maxZInput = coordinateInput("Max chunk Z");
            row.addView(maxXInput, new LinearLayout.LayoutParams(0, dp(52), 1));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(52), 1);
            p.leftMargin = dp(8);
            row.addView(maxZInput, p);
        }
        return row;
    }

    private EditText coordinateInput(String hint) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setTextSize(14);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        input.setHint(hint);
        input.setPadding(dp(12), 0, dp(12), 0);
        input.setBackground(roundRect(PANEL_SOFT, dp(10), 0xFF30435C, dp(1)));
        return input;
    }

    private void setManualMode(boolean manual) {
        manualMode = manual;
        mapView.setVisibility(manual ? View.GONE : View.VISIBLE);
        manualPanel.setVisibility(manual ? View.VISIBLE : View.GONE);
        updateModeButtons();
    }

    private void updateModeButtons() {
        styleModeButton(modeVisual, !manualMode);
        styleModeButton(modeManual, manualMode);
    }

    private void styleModeButton(TextView button, boolean selected) {
        button.setTextColor(selected ? BG : TEXT);
        button.setBackground(roundRect(selected ? ACCENT : PANEL_SOFT, dp(9), selected ? ACCENT : 0xFF30435C, dp(1)));
    }

    private void updateSelectionStatus() {
        BigInteger width = BigInteger.valueOf((long) selectionMaxX - selectionMinX + 1L);
        BigInteger depth = BigInteger.valueOf((long) selectionMaxZ - selectionMinZ + 1L);
        BigInteger area = width.signum() > 0 && depth.signum() > 0 ? width.multiply(depth) : BigInteger.ZERO;
        selectionStatus.setText("Selected: X " + selectionMinX + " to " + selectionMaxX
                + "  ·  Z " + selectionMinZ + " to " + selectionMaxZ
                + "  ·  " + String.format("%,d", area) + " chunk columns");
    }

    private void syncManualInputs() {
        if (minXInput != null) minXInput.setText(Integer.toString(selectionMinX));
        if (minZInput != null) minZInput.setText(Integer.toString(selectionMinZ));
        if (maxXInput != null) maxXInput.setText(Integer.toString(selectionMaxX));
        if (maxZInput != null) maxZInput.setText(Integer.toString(selectionMaxZ));
    }

    private boolean readSelection() {
        if (!manualMode) return true;
        try {
            selectionMinX = Integer.parseInt(minXInput.getText().toString().trim());
            selectionMinZ = Integer.parseInt(minZInput.getText().toString().trim());
            selectionMaxX = Integer.parseInt(maxXInput.getText().toString().trim());
            selectionMaxZ = Integer.parseInt(maxZInput.getText().toString().trim());
            if (selectionMinX > selectionMaxX || selectionMinZ > selectionMaxZ) {
                toast("Minimum coordinates must be less than or equal to maximum coordinates.");
                return false;
            }
            mapView.setRegion(selectionMinX, selectionMinZ, selectionMaxX, selectionMaxZ);
            updateSelectionStatus();
            return true;
        } catch (NumberFormatException exception) {
            toast("Enter all four chunk coordinates first.");
            return false;
        }
    }

    private void chooseWorld() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/octet-stream", "application/zip", "application/x-zip-compressed", "application/x-mcworld"
        });
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQUEST_OPEN_WORLD);
    }

    private void chooseExportDestination() {
        if (!worldLoaded || busy) return;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/octet-stream");
        intent.putExtra(Intent.EXTRA_TITLE, safeFileName(worldName) + "-pruned.mcworld");
        startActivityForResult(intent, REQUEST_CREATE_WORLD);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQUEST_OPEN_WORLD) {
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            importWorld(uri);
        } else if (requestCode == REQUEST_CREATE_WORLD) {
            exportWorld(uri);
        }
    }

    private void importWorld(Uri uri) {
        setBusy(true, "Importing the world and preparing a protected copy…");
        worker.execute(() -> {
            File staging = new File(workspace, "incoming");
            File oldOriginal = new File(workspace, "previous-original");
            File oldWorking = new File(workspace, "previous-working");
            boolean originalMoved = false;
            boolean workingMoved = false;
            boolean newOriginalInstalled = false;
            boolean newWorkingInstalled = false;
            try {
                if (!workspace.exists() && !workspace.mkdirs()) {
                    throw new Exception("Could not prepare app storage.");
                }
                WorldFiles.deleteRecursively(staging);
                if (!staging.mkdirs()) throw new Exception("Could not prepare the import folder.");

                File archive = new File(staging, "selected-world.mcworld");
                WorldFiles.copyUriToFile(getContentResolver(), uri, archive);
                File extracted = new File(staging, "extracted");
                File importedRoot = WorldFiles.extractWorldArchive(archive, extracted);
                File stagedOriginal = new File(staging, "original");
                File stagedWorking = new File(staging, "working");
                WorldFiles.copyDirectory(importedRoot, stagedOriginal);
                WorldFiles.copyDirectory(stagedOriginal, stagedWorking);
                String pickedName = getDisplayName(uri);
                String detectedName = WorldFiles.readWorldName(stagedOriginal, pickedName);

                // Only replace the previous session after the new import is fully copied and verified.
                WorldFiles.deleteRecursively(oldOriginal);
                WorldFiles.deleteRecursively(oldWorking);
                if (originalWorld.exists()) {
                    if (!originalWorld.renameTo(oldOriginal)) {
                        throw new Exception("Could not preserve the previous protected copy.");
                    }
                    originalMoved = true;
                }
                if (workingWorld.exists()) {
                    if (!workingWorld.renameTo(oldWorking)) {
                        throw new Exception("Could not preserve the previous working copy.");
                    }
                    workingMoved = true;
                }
                if (!stagedOriginal.renameTo(originalWorld)) {
                    throw new Exception("Could not install the new protected copy.");
                }
                newOriginalInstalled = true;
                if (!stagedWorking.renameTo(workingWorld)) {
                    throw new Exception("Could not install the new working copy.");
                }
                newWorkingInstalled = true;

                try {
                    WorldFiles.deleteRecursively(oldOriginal);
                    WorldFiles.deleteRecursively(oldWorking);
                    WorldFiles.deleteRecursively(staging);
                } catch (Exception ignored) {
                    // The new world is already installed; leftover temporary files are safer than rollback.
                }
                runOnUiThread(() -> {
                    worldName = detectedName;
                    getSharedPreferences("worldbridge", MODE_PRIVATE).edit().putString("world_name", detectedName).apply();
                    worldLoaded = true;
                    lastExportUri = null;
                    worldStatus.setText("Loaded: " + worldName + "  ·  working copy ready");
                    actionStatus.setText("Your source file is safe. Select a dimension and a chunk rectangle.");
                    openButton.setVisibility(View.GONE);
                    setBusy(false, null);
                    updateButtons();
                    loadWorldPreview();
                });
            } catch (Exception exception) {
                // Roll back the directory swap if installing the new world failed.
                try {
                    if (newWorkingInstalled) WorldFiles.deleteRecursively(workingWorld);
                    if (newOriginalInstalled) WorldFiles.deleteRecursively(originalWorld);
                    if (workingMoved && oldWorking.exists()) oldWorking.renameTo(workingWorld);
                    if (originalMoved && oldOriginal.exists()) oldOriginal.renameTo(originalWorld);
                } catch (Exception ignored) {
                    // Keep any remaining backup directories rather than deleting the only recoverable copy.
                }
                runOnUiThread(() -> {
                    setBusy(false, null);
                    actionStatus.setText("Import failed: " + friendlyMessage(exception));
                    toast("Could not import that world. Your previous session was kept where possible.");
                    updateButtons();
                });
            }
        });
    }

    private void reviewAndPrune() {
        if (!worldLoaded || busy || !readSelection()) return;
        int dimensionIndex = dimensionSpinner.getSelectedItemPosition();
        String dimensionName = new String[]{"Overworld", "Nether", "The End"}[dimensionIndex];
        BigInteger columns = BigInteger.valueOf((long) selectionMaxX - selectionMinX + 1L)
                .multiply(BigInteger.valueOf((long) selectionMaxZ - selectionMinZ + 1L));
        String details = "Dimension: " + dimensionName
                + "\nChunk X: " + selectionMinX + " through " + selectionMaxX
                + "\nChunk Z: " + selectionMinZ + " through " + selectionMaxZ
                + "\nRectangle size: " + String.format("%,d", columns) + " chunk positions"
                + "\n\nOnly records belonging to chunk columns inside this rectangle will be deleted. All other dimensions and all chunks outside the rectangle are kept.\n\nThe imported .mcworld file and the protected original copy are not changed.";

        new AlertDialog.Builder(this)
                .setTitle("Review chunk removal")
                .setMessage(details)
                .setNegativeButton("Go back", null)
                .setPositiveButton("Delete selected chunks", (dialog, which) -> pruneSelected(dimensionIndex))
                .show();
    }

    private void pruneSelected(int dimensionIndex) {
        final int minX = selectionMinX;
        final int minZ = selectionMinZ;
        final int maxX = selectionMaxX;
        final int maxZ = selectionMaxZ;
        final int dimensionId = dimensionIndex;
        final String dimensionName = new String[]{"Overworld", "Nether", "The End"}[dimensionIndex];
        setBusy(true, "Scanning and removing selected chunk records…");
        worker.execute(() -> {
            try {
                File scratch = new File(workspace, "scratch");
                BedrockChunkPruner.Result result = BedrockChunkPruner.prune(
                        workingWorld, dimensionId, minX, minZ, maxX, maxZ, scratch
                );
                runOnUiThread(() -> {
                    setBusy(false, null);
                    actionStatus.setText("Finished: " + String.format("%,d", result.chunkColumns)
                            + " chunk columns found; " + String.format("%,d", result.recordsDeleted)
                            + " LevelDB records removed from " + dimensionName + ".");
                    if (result.recordsDeleted == 0) {
                        toast("No saved chunks were found inside that rectangle.");
                    } else {
                        toast("Selected chunks removed from the working copy.");
                    }
                    lastExportUri = null;
                    openButton.setVisibility(View.GONE);
                    updateButtons();
                    loadWorldPreview();
                });
            } catch (Exception exception) {
                runOnUiThread(() -> {
                    setBusy(false, null);
                    actionStatus.setText("Pruning failed: " + friendlyMessage(exception));
                    toast("The working copy was not exported. Check the world file and try again.");
                    updateButtons();
                });
            }
        });
    }

    private void exportWorld(Uri destination) {
        if (!worldLoaded || busy) return;
        setBusy(true, "Packing the edited world into a .mcworld file…");
        worker.execute(() -> {
            try {
                OutputStream output = getContentResolver().openOutputStream(destination, "w");
                if (output == null) throw new Exception("Android could not open the export destination.");
                WorldFiles.writeMcworld(workingWorld, output);
                runOnUiThread(() -> {
                    lastExportUri = destination;
                    setBusy(false, null);
                    actionStatus.setText("Export complete. Open the saved .mcworld file with Minecraft to import it.");
                    openButton.setVisibility(View.VISIBLE);
                    toast("World exported successfully.");
                    updateButtons();
                });
            } catch (Exception exception) {
                runOnUiThread(() -> {
                    setBusy(false, null);
                    actionStatus.setText("Export failed: " + friendlyMessage(exception));
                    toast("Could not export the world.");
                    updateButtons();
                });
            }
        });
    }

    private void openLastExport() {
        if (lastExportUri == null) return;
        try {
            Intent open = new Intent(Intent.ACTION_VIEW);
            open.setDataAndType(lastExportUri, "application/octet-stream");
            open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(open);
        } catch (Exception exception) {
            toast("Open the saved .mcworld file from your Downloads or Files app.");
        }
    }

    private void confirmReset() {
        if (!worldLoaded || busy) return;
        new AlertDialog.Builder(this)
                .setTitle("Restore original copy?")
                .setMessage("This replaces the edited working copy with the protected copy made during import. The original .mcworld file remains untouched.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Restore", (dialog, which) -> resetWorkingCopy())
                .show();
    }

    private void resetWorkingCopy() {
        setBusy(true, "Restoring the original working copy…");
        worker.execute(() -> {
            try {
                WorldFiles.copyDirectory(originalWorld, workingWorld);
                lastExportUri = null;
                runOnUiThread(() -> {
                    setBusy(false, null);
                    actionStatus.setText("Restored. No chunks have been pruned in this working copy.");
                    openButton.setVisibility(View.GONE);
                    updateButtons();
                    loadWorldPreview();
                });
            } catch (Exception exception) {
                runOnUiThread(() -> {
                    setBusy(false, null);
                    actionStatus.setText("Restore failed: " + friendlyMessage(exception));
                    updateButtons();
                });
            }
        });
    }

    private void restoreWorkspace() {
        if (new File(originalWorld, "level.dat").isFile()
                && new File(originalWorld, "db").isDirectory()
                && new File(workingWorld, "level.dat").isFile()
                && new File(workingWorld, "db").isDirectory()) {
            SharedPreferences preferences = getSharedPreferences("worldbridge", MODE_PRIVATE);
            worldName = WorldFiles.readWorldName(originalWorld, preferences.getString("world_name", "Imported Bedrock world"));
            worldLoaded = true;
            worldStatus.setText("Loaded: " + worldName + "  ·  working copy ready");
            actionStatus.setText("Previous working copy restored. Continue selecting or export it.");
            loadWorldPreview();
        }
        updateButtons();
    }

    private void loadWorldPreview() {
        if (!worldLoaded || busy || mapView == null) return;
        final int requestId = ++previewRequestId;
        final int dimensionId = dimensionSpinner.getSelectedItemPosition();
        previewStatus.setText("Reading saved chunks and building the map preview…");
        worker.execute(() -> {
            try {
                BedrockWorldPreview.PreviewData data = BedrockWorldPreview.scan(workingWorld, dimensionId);
                runOnUiThread(() -> {
                    if (requestId != previewRequestId || !worldLoaded) return;
                    mapView.setPreview(data);
                    mapView.setRegion(selectionMinX, selectionMinZ, selectionMaxX, selectionMaxZ);
                    if (data.getChunkCount() == 0) {
                        previewStatus.setText("No saved chunk columns were found in this dimension.");
                    } else if (data.hasBiomeOrHeightData) {
                        previewStatus.setText(String.format("%,d saved chunk columns · stored biome/height data · approximate terrain colours · drag to select", data.getChunkCount()));
                    } else {
                        previewStatus.setText(String.format("%,d saved chunk columns · this world has no readable 2D biome/height map records; showing chunk coverage", data.getChunkCount()));
                    }
                });
            } catch (Exception exception) {
                runOnUiThread(() -> {
                    if (requestId != previewRequestId) return;
                    previewStatus.setText("Map preview unavailable: " + friendlyMessage(exception));
                    mapView.setPreview(null);
                });
            }
        });
    }

    private String getDisplayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) {
        }
        return "Imported Bedrock world";
    }

    private void setBusy(boolean value, String message) {
        busy = value;
        progressBar.setVisibility(value ? View.VISIBLE : View.GONE);
        if (message != null) actionStatus.setText(message);
        updateButtons();
    }

    private void updateButtons() {
        if (importButton == null) return;
        importButton.setEnabled(!busy);
        pruneButton.setEnabled(worldLoaded && !busy);
        exportButton.setEnabled(worldLoaded && !busy);
        resetButton.setEnabled(worldLoaded && !busy);
        importButton.setAlpha(busy ? 0.55f : 1f);
        pruneButton.setAlpha(worldLoaded && !busy ? 1f : 0.48f);
        exportButton.setAlpha(worldLoaded && !busy ? 1f : 0.48f);
        resetButton.setAlpha(worldLoaded && !busy ? 1f : 0.48f);
    }

    private String friendlyMessage(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.trim().isEmpty() ? exception.getClass().getSimpleName() : message;
    }

    private String safeFileName(String name) {
        String safe = name == null ? "World" : name.replaceAll("[^A-Za-z0-9._-]+", "-").replaceAll("^-+|-+$", "");
        return safe.isEmpty() ? "World" : safe;
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private LinearLayout panel() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(15), dp(15), dp(15), dp(15));
        layout.setBackground(roundRect(PANEL, dp(16), 0xFF22334A, dp(1)));
        return layout;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private TextView modeButton(String value, boolean selected) {
        TextView view = label(value, 13, selected ? BG : TEXT, true);
        view.setGravity(Gravity.CENTER);
        styleModeButton(view, selected);
        return view;
    }

    private Button actionButton(String value, int background, int foreground) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextAllCaps(false);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(foreground);
        button.setPadding(dp(14), dp(5), dp(14), dp(5));
        button.setBackground(roundRect(background, dp(11), background, 0));
        return button;
    }

    private GradientDrawable roundRect(int color, float radius, int strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        if (strokeWidth > 0) drawable.setStroke(strokeWidth, strokeColor);
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams margin(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = matchWrap();
        params.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return params;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        worker.shutdown();
    }
}
