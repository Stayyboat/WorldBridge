package com.worldbridge.app;

import android.content.ContentResolver;
import android.net.Uri;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.charset.StandardCharsets;
import java.util.Comparator;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

final class WorldFiles {
    private static final long MAX_UNPACKED_BYTES = 6L * 1024L * 1024L * 1024L;
    private static final int MAX_ENTRIES = 250_000;
    private static final int BUFFER_SIZE = 64 * 1024;

    private WorldFiles() {
    }

    static void copyUriToFile(ContentResolver resolver, Uri uri, File destination) throws IOException {
        File parent = destination.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            throw new IOException("Could not create the import folder.");
        }
        try (InputStream input = resolver.openInputStream(uri);
             OutputStream output = new BufferedOutputStream(new FileOutputStream(destination))) {
            if (input == null) throw new IOException("Android could not open that file.");
            byte[] buffer = new byte[BUFFER_SIZE];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
        }
    }

    static File extractWorldArchive(File archive, File destination) throws IOException {
        deleteRecursively(destination);
        if (!destination.mkdirs()) throw new IOException("Could not prepare the world import folder.");

        String canonicalRoot = destination.getCanonicalPath() + File.separator;
        long unpacked = 0;
        int entries = 0;
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(new FileInputStream(archive)))) {
            ZipEntry entry;
            byte[] buffer = new byte[BUFFER_SIZE];
            while ((entry = zip.getNextEntry()) != null) {
                if (++entries > MAX_ENTRIES) throw new IOException("The world archive contains too many files.");
                String name = entry.getName().replace('\\', '/');
                if (name.startsWith("/") || name.contains("../") || name.equals("..")) {
                    throw new IOException("The world archive contains an unsafe file path.");
                }
                File output = new File(destination, name);
                String canonicalOutput = output.getCanonicalPath();
                if (!canonicalOutput.startsWith(canonicalRoot) && !canonicalOutput.equals(destination.getCanonicalPath())) {
                    throw new IOException("The world archive contains an unsafe file path.");
                }
                if (entry.isDirectory()) {
                    if (!output.exists() && !output.mkdirs()) throw new IOException("Could not extract a world folder.");
                } else {
                    File parent = output.getParentFile();
                    if (parent != null && !parent.exists() && !parent.mkdirs()) {
                        throw new IOException("Could not create a world folder.");
                    }
                    try (OutputStream out = new BufferedOutputStream(new FileOutputStream(output))) {
                        int read;
                        while ((read = zip.read(buffer)) != -1) {
                            unpacked += read;
                            if (unpacked > MAX_UNPACKED_BYTES) {
                                throw new IOException("The extracted world is larger than the 6 GB safety limit.");
                            }
                            out.write(buffer, 0, read);
                        }
                    }
                }
                zip.closeEntry();
            }
        }

        File root = findWorldRoot(destination);
        if (root == null) {
            throw new IOException("No Bedrock world was found in that .mcworld file. It must contain level.dat and a db folder.");
        }
        return root;
    }

    static File findWorldRoot(File extracted) throws IOException {
        if (isWorldDirectory(extracted)) return extracted;
        try (java.util.stream.Stream<Path> paths = Files.walk(extracted.toPath(), 5)) {
            return paths.filter(Files::isDirectory)
                    .map(Path::toFile)
                    .filter(WorldFiles::isWorldDirectory)
                    .min(Comparator.comparingInt(file -> file.getAbsolutePath().length()))
                    .orElse(null);
        }
    }

    private static boolean isWorldDirectory(File directory) {
        return directory.isDirectory()
                && new File(directory, "level.dat").isFile()
                && new File(directory, "db").isDirectory();
    }

    static void copyDirectory(File source, File destination) throws IOException {
        if (!isWorldDirectory(source)) throw new IOException("Source is not a Minecraft Bedrock world folder.");
        deleteRecursively(destination);
        Path sourcePath = source.toPath();
        try (java.util.stream.Stream<Path> paths = Files.walk(sourcePath)) {
            for (Path path : (Iterable<Path>) paths::iterator) {
                if (Files.isSymbolicLink(path)) continue;
                Path relative = sourcePath.relativize(path);
                Path target = destination.toPath().resolve(relative.toString());
                if (Files.isDirectory(path)) {
                    Files.createDirectories(target);
                } else {
                    Files.createDirectories(target.getParent());
                    Files.copy(path, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
                }
            }
        }
        if (!isWorldDirectory(destination)) throw new IOException("The working world copy could not be verified.");
    }

    static String readWorldName(File worldDirectory, String fallback) {
        File nameFile = new File(worldDirectory, "levelname.txt");
        if (nameFile.isFile()) {
            try {
                String name = new String(Files.readAllBytes(nameFile.toPath()), StandardCharsets.UTF_8).trim();
                if (!name.isEmpty()) return name;
            } catch (Exception ignored) {
            }
        }
        return fallback == null || fallback.trim().isEmpty() ? "Imported Bedrock world" : fallback;
    }

    static void writeMcworld(File worldDirectory, OutputStream destination) throws IOException {
        if (!isWorldDirectory(worldDirectory)) throw new IOException("The edited world folder is missing required Bedrock files.");
        try (ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(destination))) {
            zip.setLevel(Deflater.BEST_SPEED);
            Path root = worldDirectory.toPath();
            try (java.util.stream.Stream<Path> paths = Files.walk(root)) {
                for (Path path : (Iterable<Path>) paths::iterator) {
                    if (Files.isDirectory(path) || Files.isSymbolicLink(path)) continue;
                    Path relative = root.relativize(path);
                    String entryName = relative.toString().replace(File.separatorChar, '/');
                    zip.putNextEntry(new ZipEntry(entryName));
                    try (InputStream input = new BufferedInputStream(new FileInputStream(path.toFile()))) {
                        byte[] buffer = new byte[BUFFER_SIZE];
                        int read;
                        while ((read = input.read(buffer)) != -1) zip.write(buffer, 0, read);
                    }
                    zip.closeEntry();
                }
            }
            zip.finish();
        }
    }

    static void deleteRecursively(File file) throws IOException {
        if (file == null || !file.exists()) return;
        Path root = file.toPath();
        try (java.util.stream.Stream<Path> paths = Files.walk(root)) {
            Path[] all = paths.sorted(Comparator.reverseOrder()).toArray(Path[]::new);
            for (Path path : all) Files.deleteIfExists(path);
        }
    }
}
