@echo off
setlocal
set GRADLE_VERSION=9.8.2
set GRADLE_NAME=gradle-%GRADLE_VERSION%-bin
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set INSTALL_ROOT=%GRADLE_USER_HOME%\worldbridge-distributions
set GRADLE_HOME=%INSTALL_ROOT%\%GRADLE_NAME%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%INSTALL_ROOT%" mkdir "%INSTALL_ROOT%"
  set ARCHIVE=%INSTALL_ROOT%\%GRADLE_NAME%.zip
  echo Downloading Gradle %GRADLE_VERSION%...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/%GRADLE_NAME%.zip' -OutFile '%INSTALL_ROOT%\%GRADLE_NAME%.zip'; Expand-Archive -LiteralPath '%INSTALL_ROOT%\%GRADLE_NAME%.zip' -DestinationPath '%INSTALL_ROOT%' -Force; Remove-Item '%INSTALL_ROOT%\%GRADLE_NAME%.zip'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
endlocal
