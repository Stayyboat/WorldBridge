plugins {
    `java-library`
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(17))
    }
}

dependencies {
    api("com.hivemc.leveldb:leveldb:1.1.0")
    api("com.hivemc.leveldb:leveldb-api:1.1.0")
}
