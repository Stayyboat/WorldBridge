package com.worldbridge.engine;

import org.iq80.leveldb.CompressionType;
import org.iq80.leveldb.DB;
import org.iq80.leveldb.DBFactory;
import org.iq80.leveldb.DBIterator;
import org.iq80.leveldb.Options;
import org.iq80.leveldb.ReadOptions;
import org.iq80.leveldb.WriteBatch;
import org.iq80.leveldb.impl.Iq80DBFactory;
import org.iq80.leveldb.table.BloomFilterPolicy;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteOrder;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Map;

/**
 * Removes selected Bedrock chunk-column records from a copied world's LevelDB.
 *
 * The key layouts and deletion rules follow the Bedrock LevelDB handling used by
 * HiveGamesOSS/Chunker (MIT licensed). This deliberately changes only records
 * whose keys identify a chunk column in the selected dimension and rectangle.
 */
public final class BedrockChunkPruner {
    private static final byte[] LOCAL_PLAYER_KEY = "~local_player".getBytes(StandardCharsets.UTF_8);
    private static final int BATCH_SIZE = 1000;
    private static final byte VERSION = 44;
    private static final byte LEGACY_VERSION = 118;

    private BedrockChunkPruner() {
    }

    public static Result prune(
            File worldDirectory,
            int dimensionId,
            int minChunkX,
            int minChunkZ,
            int maxChunkX,
            int maxChunkZ,
            File scratchDirectory
    ) throws IOException {
        validate(worldDirectory, dimensionId, minChunkX, minChunkZ, maxChunkX, maxChunkZ);
        if (!scratchDirectory.exists() && !scratchDirectory.mkdirs()) {
            throw new IOException("Could not create temporary working directory.");
        }

        File dbDirectory = new File(worldDirectory, "db");
        // Only the working copy is opened. The imported .mcworld remains untouched.
        // Chunker also removes a stale LOCK marker before opening a copied world DB.
        File lock = new File(dbDirectory, "LOCK");
        if (lock.exists() && !lock.delete()) {
            throw new IOException("Could not clear a stale LevelDB lock in the working copy.");
        }

        File keySpool = File.createTempFile("worldbridge-prune-", ".keys", scratchDirectory);
        long recordCount = 0;
        long columnCount = 0;
        DB database = null;
        try {
            Options options = new Options();
            options.createIfMissing(false);
            options.compressionType(CompressionType.ZLIB_RAW);
            options.blockSize(160 * 1024);
            options.filterPolicy(new BloomFilterPolicy(10));
            // Smaller than Chunker's desktop default to avoid a huge write buffer on phones.
            options.writeBufferSize(8 * 1024 * 1024);

            DBFactory factory = new Iq80DBFactory();
            database = factory.open(dbDirectory, options);

            // First pass: spool matching keys to disk. We close the iterator before
            // writing so iteration is not affected by modifications to the DB.
            try (DataOutputStream spool = new DataOutputStream(
                    new BufferedOutputStream(new FileOutputStream(keySpool))
            ); DBIterator iterator = database.iterator(new ReadOptions().fillCache(false))) {
                while (iterator.hasNext()) {
                    Map.Entry<byte[], byte[]> entry = iterator.next();
                    byte[] key = entry.getKey();
                    ParsedChunkKey parsed = parseChunkKey(key);
                    if (parsed == null) continue;
                    if (parsed.dimensionId != dimensionId) continue;
                    if (parsed.chunkX < minChunkX || parsed.chunkX > maxChunkX
                            || parsed.chunkZ < minChunkZ || parsed.chunkZ > maxChunkZ) {
                        continue;
                    }

                    spool.writeInt(key.length);
                    spool.write(key);
                    recordCount++;
                    if (parsed.isColumnVersion) columnCount++;
                }
            }

            // Second pass: delete in bounded batches to keep memory predictable.
            try (DataInputStream input = new DataInputStream(
                    new BufferedInputStream(new FileInputStream(keySpool))
            )) {
                boolean finished = false;
                while (!finished) {
                    int batchEntries = 0;
                    try (WriteBatch batch = database.createWriteBatch()) {
                        while (batchEntries < BATCH_SIZE) {
                            int length;
                            try {
                                length = input.readInt();
                            } catch (EOFException eof) {
                                finished = true;
                                break;
                            }
                            if (length < 9 || length > 14) {
                                throw new IOException("Invalid temporary chunk key length.");
                            }
                            byte[] key = new byte[length];
                            input.readFully(key);
                            batch.delete(key);
                            batchEntries++;
                        }
                        if (batchEntries > 0) database.write(batch);
                    }
                }
            }

            // Compact tombstones so the exported world can reclaim deleted chunk storage.
            // This is the same final LevelDB compaction step used by Chunker.
            database.compactRange(null, null);

            // Close/flush before returning the updated world to Minecraft.
            database.close();
            database = null;
            return new Result(columnCount, recordCount);
        } finally {
            if (database != null) {
                try {
                    database.close();
                } catch (Exception ignored) {
                    // Preserve the original exception.
                }
            }
            if (keySpool.exists() && !keySpool.delete()) {
                // The temporary file is private to the app and will be removed on cleanup.
            }
        }
    }

    private static void validate(
            File worldDirectory,
            int dimensionId,
            int minChunkX,
            int minChunkZ,
            int maxChunkX,
            int maxChunkZ
    ) throws IOException {
        if (worldDirectory == null || !worldDirectory.isDirectory()) {
            throw new IOException("World folder not found.");
        }
        File levelDat = new File(worldDirectory, "level.dat");
        File dbDirectory = new File(worldDirectory, "db");
        if (!levelDat.isFile() || !dbDirectory.isDirectory()) {
            throw new IOException("This does not look like a Minecraft Bedrock world (level.dat and db/ are required).");
        }
        if (dimensionId < 0 || dimensionId > 2) {
            throw new IOException("Unsupported dimension.");
        }
        if (minChunkX > maxChunkX || minChunkZ > maxChunkZ) {
            throw new IOException("The minimum chunk coordinates must not be greater than the maximum coordinates.");
        }
    }

    /**
     * Parse the Bedrock chunk key forms used by Chunker:
     * 9/10 bytes = Overworld; 13/14 bytes = dimension-bearing key.
     */
    private static ParsedChunkKey parseChunkKey(byte[] key) {
        if (Arrays.equals(key, LOCAL_PLAYER_KEY)) return null;
        int length = key.length;
        boolean hasSubChunk = length == 14 || length == 10;
        boolean hasDimension = length == 14 || length == 13;
        if (length != 9 && !hasSubChunk && !hasDimension) return null;

        ByteBuffer buffer = ByteBuffer.wrap(key).order(ByteOrder.LITTLE_ENDIAN);
        int x = buffer.getInt();
        int z = buffer.getInt();
        int dimension = hasDimension ? buffer.getInt() : 0;
        // We don't need the sub-chunk Y/type for matching, but validate the layout.
        if (hasSubChunk) buffer.get();
        byte type = buffer.get();
        boolean versionKey = (length == 9 || length == 13)
                && (type == VERSION || type == LEGACY_VERSION);
        return new ParsedChunkKey(x, z, dimension, versionKey);
    }

    private static final class ParsedChunkKey {
        final int chunkX;
        final int chunkZ;
        final int dimensionId;
        final boolean isColumnVersion;

        ParsedChunkKey(int chunkX, int chunkZ, int dimensionId, boolean isColumnVersion) {
            this.chunkX = chunkX;
            this.chunkZ = chunkZ;
            this.dimensionId = dimensionId;
            this.isColumnVersion = isColumnVersion;
        }
    }

    public static final class Result {
        public final long chunkColumns;
        public final long recordsDeleted;

        public Result(long chunkColumns, long recordsDeleted) {
            this.chunkColumns = chunkColumns;
            this.recordsDeleted = recordsDeleted;
        }
    }
}
