package com.worldbridge.engine;

import org.iq80.leveldb.CompressionType;
import org.iq80.leveldb.DB;
import org.iq80.leveldb.DBFactory;
import org.iq80.leveldb.DBIterator;
import org.iq80.leveldb.Options;
import org.iq80.leveldb.ReadOptions;
import org.iq80.leveldb.impl.Iq80DBFactory;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Builds a lightweight top-down preview from Bedrock's stored chunk, height-map and biome records.
 * It does not change the world database. The preview is an overview, not a block-perfect renderer.
 */
public final class BedrockWorldPreview {
    private static final byte DATA_3D = 43;
    private static final byte VERSION = 44;
    private static final byte DATA_2D = 45;
    private static final byte LEGACY_VERSION = 118;
    private static final byte[] LOCAL_PLAYER = "~local_player".getBytes(StandardCharsets.UTF_8);
    private static final byte[] ACTOR_PREFIX = "actorprefix".getBytes(StandardCharsets.UTF_8);
    private static final byte[] DIGP_PREFIX = "digp".getBytes(StandardCharsets.UTF_8);
    private static final byte[] MAP_PREFIX = "map_".getBytes(StandardCharsets.UTF_8);

    private BedrockWorldPreview() {
    }

    public static PreviewData scan(File worldDirectory, int dimensionId) throws IOException {
        if (worldDirectory == null || !new File(worldDirectory, "level.dat").isFile()
                || !new File(worldDirectory, "db").isDirectory()) {
            throw new IOException("The selected folder is not a Bedrock world.");
        }
        if (dimensionId < 0 || dimensionId > 2) throw new IOException("Unsupported dimension.");

        File dbDirectory = new File(worldDirectory, "db");
        Options options = new Options()
                .createIfMissing(false)
                .compressionType(CompressionType.ZLIB_RAW)
                .cacheSize(4L * 1024L * 1024L)
                .writeBufferSize(1024 * 1024);
        DB database = null;
        try {
            DBFactory factory = new Iq80DBFactory();
            database = factory.open(dbDirectory, options);
            List<ChunkPosition> columns = new ArrayList<>();
            try (DBIterator iterator = database.iterator(new ReadOptions().fillCache(false))) {
                while (iterator.hasNext()) {
                    byte[] key = iterator.next().getKey();
                    if (!isColumnVersionKey(key)) continue;
                    int x = readIntLE(key, 0);
                    int z = readIntLE(key, 4);
                    int keyDimension = key.length == 13 ? readIntLE(key, 8) : 0;
                    if (keyDimension == dimensionId) columns.add(new ChunkPosition(x, z));
                }
            }

            Map<Long, int[]> tiles = new HashMap<>(Math.max(16, columns.size() * 4 / 3));
            int minX = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
            int maxX = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
            boolean hasBiomeOrHeightData = false;
            for (ChunkPosition position : columns) {
                byte[] data2d = database.get(chunkKey(position.x, position.z, dimensionId, DATA_2D));
                byte[] data3d = database.get(chunkKey(position.x, position.z, dimensionId, DATA_3D));
                int[] colors = makeTile(data2d, data3d, dimensionId);
                if ((data2d != null && data2d.length >= 512) || (data3d != null && data3d.length >= 512)) hasBiomeOrHeightData = true;
                tiles.put(key(position.x, position.z), colors);
                minX = Math.min(minX, position.x);
                minZ = Math.min(minZ, position.z);
                maxX = Math.max(maxX, position.x);
                maxZ = Math.max(maxZ, position.z);
            }
            if (database != null) {
                database.close();
                database = null;
            }
            if (columns.isEmpty()) return new PreviewData(tiles, 0, -1, 0, -1, false);
            return new PreviewData(tiles, minX, maxX, minZ, maxZ, hasBiomeOrHeightData);
        } catch (RuntimeException exception) {
            throw new IOException("Could not read the world's Bedrock database: " + safeMessage(exception), exception);
        } finally {
            if (database != null) {
                try { database.close(); } catch (Exception ignored) { }
            }
        }
    }

    private static int[] makeTile(byte[] data2d, byte[] data3d, int dimensionId) {
        int[] colors = new int[16];
        byte[] heightSource = data3d != null && data3d.length >= 512 ? data3d : data2d;
        if (heightSource == null || heightSource.length < 512) {
            Arrays.fill(colors, dimensionId == 1 ? 0xFF713E35 : dimensionId == 2 ? 0xFF76628C : 0xFF46576A);
            return colors;
        }

        ByteBuffer heightBuffer = ByteBuffer.wrap(heightSource).order(ByteOrder.LITTLE_ENDIAN);
        short[] heights = new short[256];
        for (int i = 0; i < 256; i++) heights[i] = heightBuffer.getShort();
        int[] biomes = new int[256];
        boolean has3dBiomeData = data3d != null && data3d.length > 512;
        if (!has3dBiomeData && data2d != null && data2d.length >= 768) {
            ByteBuffer biomeBuffer = ByteBuffer.wrap(data2d).order(ByteOrder.LITTLE_ENDIAN);
            biomeBuffer.position(512);
            for (int i = 0; i < 256; i++) biomes[i] = biomeBuffer.get() & 0xFF;
        } else {
            Arrays.fill(biomes, dimensionId == 1 ? 8 : dimensionId == 2 ? 9 : 1);
        }

        int[] sampleX = new int[16];
        int[] sampleZ = new int[16];
        int[] targetSubChunk = new int[16];
        int[] localY = new int[16];
        for (int tz = 0; tz < 4; tz++) {
            for (int tx = 0; tx < 4; tx++) {
                int sample = tz * 4 + tx;
                int x = tx * 4 + 2;
                int z = tz * 4 + 2;
                sampleX[sample] = x;
                sampleZ[sample] = z;
                int height = heights[z * 16 + x];
                int minSubChunk = dimensionId == 0 ? -4 : 0;
                targetSubChunk[sample] = Math.floorDiv(height, 16) - minSubChunk;
                localY[sample] = Math.floorMod(height, 16);
            }
        }

        // In 1.18+ Bedrock stores the height map first, followed by 3D biome palettes in Data3D.
        if (has3dBiomeData) {
            try {
                byte[] palettes = Arrays.copyOfRange(data3d, 512, data3d.length);
                apply3dBiomes(palettes, dimensionId, sampleX, sampleZ, targetSubChunk, localY, biomes);
            } catch (Exception ignored) {
                // Keep the 2D biome values or dimension fallback if a world uses an unsupported palette encoding.
            }
        }

        for (int tz = 0; tz < 4; tz++) {
            for (int tx = 0; tx < 4; tx++) {
                int sample = tz * 4 + tx;
                int x = sampleX[sample];
                int z = sampleZ[sample];
                int height = heights[z * 16 + x];
                int biome = biomes[z * 16 + x];
                colors[sample] = shade(biomeColor(biome, dimensionId), height);
            }
        }
        return colors;
    }

    /** Reads only the 4x4 sample positions needed by the preview from Bedrock's packed 3D biome palettes. */
    private static void apply3dBiomes(byte[] bytes, int dimensionId, int[] sampleX, int[] sampleZ,
                                      int[] targetSubChunk, int[] localY, int[] output) {
        ByteBuffer input = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        int maxTarget = -1;
        for (int value : targetSubChunk) maxTarget = Math.max(maxTarget, value);
        int paletteIndex = 0;
        while (input.hasRemaining() && paletteIndex <= maxTarget && paletteIndex < 32) {
            int paletteData = input.get() & 0xFF;
            int bits = paletteData >>> 1;
            if (bits == 127) {
                paletteIndex++;
                continue;
            }
            int valuesPerWord = bits == 0 ? 0 : 32 / bits;
            int wordCount = valuesPerWord == 0 ? 0 : (int) Math.ceil(4096.0 / valuesPerWord);
            int[] words = new int[wordCount];
            for (int i = 0; i < wordCount; i++) words[i] = input.getInt();
            int paletteSize = bits == 0 ? 1 : input.getInt();
            if (paletteSize < 0 || paletteSize > 4096) throw new IllegalArgumentException("Invalid biome palette size");
            int[] ids = new int[paletteSize];
            for (int i = 0; i < paletteSize; i++) ids[i] = input.getInt();

            for (int sample = 0; sample < 16; sample++) {
                if (targetSubChunk[sample] != paletteIndex || paletteSize == 0) continue;
                int blockIndex = (sampleX[sample] << 8) | (sampleZ[sample] << 4) | localY[sample];
                int paletteValue = 0;
                if (bits > 0) {
                    int word = words[blockIndex / valuesPerWord];
                    paletteValue = (word >>> ((blockIndex % valuesPerWord) * bits)) & ((1 << bits) - 1);
                }
                if (paletteValue >= 0 && paletteValue < ids.length) {
                    output[sampleZ[sample] * 16 + sampleX[sample]] = ids[paletteValue];
                }
            }
            paletteIndex++;
        }
    }

    private static boolean isColumnVersionKey(byte[] key) {
        int length = key.length;
        if (length != 9 && length != 13) return false;
        if (startsWith(key, ACTOR_PREFIX) || startsWith(key, DIGP_PREFIX)
                || startsWith(key, MAP_PREFIX) || Arrays.equals(key, LOCAL_PLAYER)) return false;
        byte type = key[length - 1];
        return type == VERSION || type == LEGACY_VERSION;
    }

    private static byte[] chunkKey(int x, int z, int dimensionId, byte type) {
        ByteBuffer buffer = ByteBuffer.allocate(dimensionId == 0 ? 9 : 13).order(ByteOrder.LITTLE_ENDIAN);
        buffer.putInt(x).putInt(z);
        if (dimensionId != 0) buffer.putInt(dimensionId);
        buffer.put(type);
        return buffer.array();
    }

    private static int readIntLE(byte[] bytes, int offset) {
        return (bytes[offset] & 0xFF) | ((bytes[offset + 1] & 0xFF) << 8)
                | ((bytes[offset + 2] & 0xFF) << 16) | (bytes[offset + 3] << 24);
    }

    private static boolean startsWith(byte[] input, byte[] prefix) {
        if (input.length < prefix.length) return false;
        for (int i = 0; i < prefix.length; i++) if (input[i] != prefix[i]) return false;
        return true;
    }

    private static int biomeColor(int id, int dimension) {
        if (dimension == 1 && id < 8) return 0xFF914D3E;
        if (dimension == 2 && id < 10) return 0xFF9581B2;
        switch (id) {
            case 0: case 24: case 41: case 43: case 45: case 47: return 0xFF376D9C;
            case 1: case 129: return 0xFF91B85B;
            case 2: case 17: case 130: return 0xFFE1C17C;
            case 3: case 20: case 131: case 162: case 182: case 189: return 0xFF8B918D;
            case 4: case 18: case 27: case 28: case 29: case 132: case 155: case 156: case 157: return 0xFF4D874B;
            case 5: case 19: case 30: case 31: case 32: case 33: case 133: case 158: case 160: case 161: return 0xFF567D58;
            case 6: case 134: case 191: return 0xFF527B63;
            case 7: return 0xFF4E8BC2;
            case 8: return 0xFF9A4B3B;
            case 9: return 0xFF8573A8;
            case 10: case 11: case 12: case 13: case 26: case 46: case 183: case 184: case 185: return 0xFFC8D9E6;
            case 14: case 15: return 0xFF9C6D9A;
            case 16: case 25: return 0xFFE0D09A;
            case 21: case 22: case 23: case 48: case 49: case 149: case 151: return 0xFF367B45;
            case 35: case 36: case 163: case 164: return 0xFFB8A85D;
            case 37: case 38: case 39: case 165: case 166: case 167: return 0xFFC47748;
            case 40: case 42: case 44: return 0xFF4C9C9B;
            case 178: return 0xFF9B806B;
            case 179: return 0xFF9C493F;
            case 180: return 0xFF347A68;
            case 181: return 0xFF65666A;
            case 186: return 0xFF9DBB70;
            case 187: return 0xFF3C8064;
            case 188: return 0xFF8A7760;
            case 190: return 0xFF343B50;
            case 192: return 0xFFCE8AAE;
            case 193: return 0xFF687C66;
            case 194: return 0xFFB7A43C;
            case 195: return 0xFF6E965A;
            case 196: return 0xFFA9C9D5;
            default: return 0xFF73816F;
        }
    }

    private static int shade(int color, int height) {
        float factor = 0.88f + Math.max(0, Math.min(220, height - 48)) / 220f * 0.18f;
        int r = Math.min(255, Math.round(((color >>> 16) & 255) * factor));
        int g = Math.min(255, Math.round(((color >>> 8) & 255) * factor));
        int b = Math.min(255, Math.round((color & 255) * factor));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static String safeMessage(Exception exception) {
        return exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage();
    }

    private static long key(int x, int z) {
        return ((long) x << 32) | (z & 0xFFFFFFFFL);
    }

    private static final class ChunkPosition {
        final int x, z;
        ChunkPosition(int x, int z) { this.x = x; this.z = z; }
    }

    public static final class PreviewData {
        public final Map<Long, int[]> tiles;
        public final int minChunkX, maxChunkX, minChunkZ, maxChunkZ;
        public final boolean hasBiomeOrHeightData;

        PreviewData(Map<Long, int[]> tiles, int minChunkX, int maxChunkX, int minChunkZ, int maxChunkZ,
                    boolean hasBiomeOrHeightData) {
            this.tiles = tiles;
            this.minChunkX = minChunkX;
            this.maxChunkX = maxChunkX;
            this.minChunkZ = minChunkZ;
            this.maxChunkZ = maxChunkZ;
            this.hasBiomeOrHeightData = hasBiomeOrHeightData;
        }

        public int getChunkCount() { return tiles.size(); }
    }
}
